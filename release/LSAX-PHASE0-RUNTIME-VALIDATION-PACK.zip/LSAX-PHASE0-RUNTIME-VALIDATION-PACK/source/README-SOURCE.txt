LSAX Phase 0 disposable probe sources - NOT LSAX PRODUCTION CODE.
Byte-identical to phase0-probes/shvdn/ at baseline commit a3701019a3c64dd859fb1e00577db47360f64066 (DRAFT2).
NEVER copy this folder into the GTA scripts folder: SHVDN compiles every .cs file under scripts.
Build on Windows with scripts\BUILD-PROBES-WINDOWS.cmd (.NET SDK 8+).

35f9aefbc71c273f3e193a5bb034eb1e12536884a5494d1bee8a606a9384851d  source/LsaxPhase0Probe/AnchorCarrierProbe.cs
349ce3806c1bf6d106f58fd763acff54aae5555d37f0c5c38de8dc184462d063  source/LsaxPhase0Probe/IdentityProbe.cs
7e3c3e8b1e92600670645ebbcdf746cce411e6cccf91bf6869b2881db1d727d0  source/LsaxPhase0Probe/LsaxPhase0Probe.csproj
6a7ab321ffdd4c21044e9b9efb124b0ec80afef96fc937b6f10183701d5b6aeb  source/LsaxPhase0Probe/ProbeCore.cs
579dbda2970ef16cac5fa350371507db6d78567ffdc90c849ddf0b1a8f549136  source/LsaxPhase0Probe/SessionSignalProbe.cs
09db1206827b0f81825f1643302d17b7f27868cd2fe6d7ffd74ca11468eea6dd  source/LsaxPhase0SqliteProbe/LsaxPhase0SqliteProbe.csproj
d61fce241983df231cc91795cd9fa63af669df95fe47315dafc0a1271e02b68f  source/LsaxPhase0SqliteProbe/SqliteReloadProbe.cs
